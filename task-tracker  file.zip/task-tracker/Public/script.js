document.getElementById('add-task').addEventListener('click', async () => {
    const taskInput = document.getElementById('task-input');
    const taskTitle = taskInput.value.trim(); // Trim whitespace

    if (taskTitle) {
        // Send POST request to add a new task
        const response = await fetch('/tasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title: taskTitle })
        });

        const newTask = await response.json();
        addTaskToUI(newTask);
        taskInput.value = ''; // Clear the input field
    }
});

// Function to add task to the UI
function addTaskToUI(task) {
    const taskList = document.getElementById('task-list');
    const li = document.createElement('li');
    li.textContent = task.title;

    // Completed checkbox
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = task.completed;
    checkbox.addEventListener('change', async () => {
        const updatedTask = await fetch(`/tasks/${task._id}`, {
            method: 'PATCH'
        });
        li.classList.toggle('completed', updatedTask.completed); // Mark as completed visually
    });

    // Delete button
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';
    deleteBtn.addEventListener('click', async () => {
        await fetch(`/tasks/${task._id}`, {
            method: 'DELETE'
        });
        taskList.removeChild(li); // Remove from UI
    });

    li.prepend(checkbox); // Add checkbox to the beginning of the list item
    li.appendChild(deleteBtn); // Add delete button
    taskList.appendChild(li);
}

// Function to fetch and display all tasks on page load
async function fetchTasks() {
    const response = await fetch('/tasks');
    const tasks = await response.json();
    tasks.forEach(addTaskToUI);
}

// Fetch tasks when the page loads
fetchTasks();
